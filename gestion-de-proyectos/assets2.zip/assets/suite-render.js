// Renders the suite hub sections from window.SUITE (see suite-data.js).
// Targets are elements with data-suite="..."; hrefs are prefixed with <body data-base="...">
// ("" at the root, "../" from clases/).

(function () {
  var S = window.SUITE;
  if (!S) return;
  var BASE = document.body.getAttribute("data-base") || "";

  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === "class") node.className = attrs[k];
      else if (k === "text") node.textContent = attrs[k];
      else node.setAttribute(k, attrs[k]);
    });
    (children || []).forEach(function (c) {
      if (c) node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
    });
    return node;
  }

  function parseDate(iso) {
    var p = iso.split("-").map(Number);
    return new Date(p[0], p[1] - 1, p[2]);
  }

  function shortDate(iso) {
    try {
      return parseDate(iso).toLocaleDateString("es-AR", { day: "numeric", month: "short" });
    } catch (e) {
      return iso;
    }
  }

  function startOfToday() {
    var n = new Date();
    return new Date(n.getFullYear(), n.getMonth(), n.getDate());
  }

  function daysUntil(iso) {
    return Math.round((parseDate(iso) - startOfToday()) / 86400000);
  }

  function classByNumber(n) {
    return S.classes.filter(function (c) { return c.number === n; })[0];
  }

  var STATUS = {
    "listo": ["Lección lista", "ok"],
    "pendiente-leccion": ["PDF listo · lección en camino", "warn"],
    "pendiente-pdf": ["Falta el PDF", "warn"],
    "fuera-tp": ["Fuera del TP", "todo"],
  };
  var SECTION_STATUS = {
    "guia": ["Guía disponible", "ok"],
    "pendiente-guia": ["Guía en camino", "warn"],
    "pendiente-clase": ["Espera una clase", "warn"],
    "al-final": ["Se arma al final", "todo"],
  };
  var MILESTONE = { entrega: "Entrega TP", parcial: "Parcial", defensa: "Defensa TP", recuperatorio: "Recuperatorio" };

  function chip(pair) {
    return el("span", { class: "chip " + pair[1], text: pair[0] });
  }

  function renderCountdown(target) {
    [["entrega", "Entrega del TP"], ["parcial", "Parcial ágil"], ["defensa", "Defensa del TP"]].forEach(function (item) {
      var iso = S.dates[item[0]];
      var d = daysUntil(iso);
      var n = d > 0 ? String(d) : d === 0 ? "Hoy" : "Pasó";
      var label = d > 0 ? "días · " + item[1] + " · " + shortDate(iso) : item[1] + " · " + shortDate(iso);
      target.appendChild(el("div", {}, [el("div", { class: "n", text: n }), el("div", { class: "l", text: label })]));
    });
  }

  function renderTimeline(target) {
    var today = startOfToday();
    var current = null;
    S.classes.forEach(function (c) { if (parseDate(c.date) <= today) current = c.number; });
    S.classes.forEach(function (c) {
      var cls = c.track === "agil" ? "is-agile" : c.track === "eval" ? "is-eval" : "";
      if (c.number === current) cls += " is-today";
      var li = el("li", { class: cls.trim(), title: c.title }, [
        el("b", { text: "C" + c.number }),
        shortDate(c.date),
        c.milestone ? el("div", { text: MILESTONE[c.milestone] }) : null,
      ]);
      target.appendChild(li);
    });
  }

  function classCard(c) {
    var ready = c.status === "listo" && c.lesson;
    var pair = STATUS[c.status] || ["", "todo"];
    // "placeholder": the page exists (reserved, no PDF yet) so the card links it while staying greyed out
    var linked = ready || (c.placeholder && c.lesson);
    var title = linked ? el("a", { href: BASE + c.lesson, text: c.title }) : document.createTextNode(c.title);
    var children = [
      el("div", { class: "top" }, [el("span", { text: "Clase " + c.number + " · " + shortDate(c.date) }), chip(pair)]),
      el("h3", {}, [title]),
      el("p", { text: c.topics }),
    ];
    if (ready) {
      (c.lessonMore || []).forEach(function (path, i) {
        var label = (c.lessonMoreLabels && c.lessonMoreLabels[i]) || path.split("/").pop().replace(".html", "");
        children.push(el("p", {}, [el("a", { href: BASE + path, text: "Continúa: " + label })]));
      });
    }
    if (ready && c.slides) {
      children.push(el("p", {}, [el("a", { href: BASE + c.slides, text: "Slides de la clase" })]));
    }
    if (c.milestone) children.push(el("p", {}, [chip(["" + MILESTONE[c.milestone], "warn"])]));
    if (c.pdf) {
      children.push(el("p", {}, [el("a", {
        class: "local-only", href: BASE + "raw/" + encodeURI(c.pdf),
        title: "Solo disponible en la copia completa con raw/", text: "PDF de la cátedra",
      })]));
    }
    var cls = "card" + (ready ? "" : " is-disabled") + (c.track === "agil" ? " is-agile" : "");
    return el("div", { class: cls }, children);
  }

  function renderClasses(target) {
    var tracks = (target.getAttribute("data-tracks") || "cascada,agil,eval").split(",");
    S.classes.filter(function (c) { return tracks.indexOf(c.track) !== -1; })
      .forEach(function (c) { target.appendChild(classCard(c)); });
  }

  function renderExtras(target) {
    var tracks = (target.getAttribute("data-tracks") || "cascada,agil").split(",");
    S.extras.filter(function (x) { return tracks.indexOf(x.track) !== -1; }).forEach(function (x) {
      var ready = x.status === "listo";
      var title = ready ? el("a", { href: BASE + x.path, text: x.title }) : document.createTextNode(x.title);
      var label = x.track === "agil" ? "Repaso · bloque ágil" : "Integración · bloque cascada";
      target.appendChild(el("div", { class: "card" + (ready ? "" : " is-disabled") + (x.track === "agil" ? " is-agile" : "") }, [
        el("div", { class: "top" }, [el("span", { text: label }), chip(STATUS[x.status] || ["", "todo"])]),
        el("h3", {}, [title]),
        el("p", { text: x.description }),
      ]));
    });
  }

  function renderTpChain(target) {
    S.tpSections.forEach(function (s) {
      var feeds = s.feedsFrom.map(function (n) { return "clase " + n; }).join(" + ");
      var attrs = feeds ? { "data-in": feeds } : {};
      var link = s.page ? el("a", { href: BASE + s.page, text: s.number + ". " + s.title }) : null;
      target.appendChild(el("li", attrs, [
        link || el("strong", { text: s.number + ". " + s.title }),
        " ",
        chip(SECTION_STATUS[s.status] || ["", "todo"]),
        el("span", { class: "q", text: s.question }),
      ]));
    });
  }

  function renderPending(target) {
    S.classes.filter(function (c) { return c.status === "pendiente-pdf"; }).forEach(function (c) {
      target.appendChild(el("li", {}, [
        el("strong", { text: "Clase " + c.number + " (" + shortDate(c.date) + ") · " + c.title + ": " }),
        c.unlocks,
      ]));
    });
    S.classes.filter(function (c) { return c.track === "agil" && !c.lesson; }).forEach(function (c) {
      target.appendChild(el("li", {}, [
        el("strong", { text: "Clase " + c.number + " (" + shortDate(c.date) + ") · " + c.title + ": " }),
        "sin material de la cátedra todavía; entra en el parcial del " + shortDate(S.dates.parcial) + ".",
      ]));
    });
  }

  var RENDERERS = {
    countdown: renderCountdown,
    timeline: renderTimeline,
    classes: renderClasses,
    extras: renderExtras,
    "tp-chain": renderTpChain,
    pending: renderPending,
  };

  Array.prototype.forEach.call(document.querySelectorAll("[data-suite]"), function (target) {
    var fn = RENDERERS[target.getAttribute("data-suite")];
    if (fn) fn(target);
  });
})();
